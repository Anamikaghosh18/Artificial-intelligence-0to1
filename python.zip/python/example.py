# a = 5 
# print(type(a)); 

# # everything in python is object 
# def hello():
#     print("Hello")

# x = hello()
# print(type(x))


# object interning -> python reuses immutable objects...
x = 5 
y = 5 

print(id(x))
print(id(y))

# a -> b , b -> a reference count = 0 , cycle automatically deletes 

list = [9, "Anamika", 9.0]
print(f"Type: {type(list)} , list is : {list}")

