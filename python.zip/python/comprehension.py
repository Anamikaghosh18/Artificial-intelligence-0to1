# [expression for varible in iterable]

# result = [(i,j) for i in range(5) for j in range(5)]

# print(result)


# conditional comprehension..
# result = [x for x in range(10) if x % 2 == 0]

# print(result)

# result = []
# for i in range(10):
#     if i % 2 == 0:
#         result.append(i)

# print(result)

# ternary comprehension
# result = ["even" if i % 2 == 0 else "odd"
#  for i in range(10)]

# print(result)


# generator expression

# # lazy evaluation
# gen_result = (x * x for x in range(10000))
# # one value at a time 


# list_result = [x * x for x in range(10000)]

# import sys 

# print(sys.getsizeof(gen_result))
# print(sys.getsizeof(list_result))


nums = [1, 2, 3]

result = [nums.append(x) for x in nums]

print(result)
print(nums)

