# iterable is an obj which produce its ele one by one. __iter__


# iterator -> obj that remember curr pos and next pos __next__()

nums = [1,2,3,4]
print(dir(nums))

# every iterator is iterable but vice versa in not true.


# for loop working and iter(range(10000000)

