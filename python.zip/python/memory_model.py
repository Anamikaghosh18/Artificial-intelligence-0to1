# Variables are names bound to objects.

# == -> same value 
# is -> value as well as object 

list = [1,2,3]


list[0] = 11 
list[0] = list[0]

print(list[0])