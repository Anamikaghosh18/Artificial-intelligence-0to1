# closures => remember teh variable after teh outer func has finished exe.

# def outer():
#     x = 10

#     def inner():
#         print(x)

#     return inner

# funcs = []

# for i in range(3):
#     def f():
#         print(i)

#     funcs.append(f)

# for fn in funcs:
#     fn()


# decorators
# 
# adding more func to a func without adding/ changing teh code 

def decorator(*args):
    print("this is a decorator")


@decorator
def print_sentence():
    pass 

print_sentence()
