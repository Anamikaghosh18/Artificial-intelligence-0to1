# metaclass --> A class whose job is to create other classes

class Person:
    pass

print(type(Person))

# Classes are objects too. And they are instances of: type 

# type( class_name, base_classes, class_attributes )

# instance -> class -> metaclass

