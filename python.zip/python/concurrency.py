# threading -> i/o
# multiprocessing => cpu
# asyncio => i/o


# concurreny => dealing with multiple task at same time . 

# parallelism => Actually running multiple tasks simultaneously.


from threading import Thread 

def work():
    print("Working")

t = Thread(target = work)
t.start() # start new thread 
t.join() # wait until the thread finishes. 


# GIL -> only one thread will execute at a time 

# due to Reference Counting



# Asyncio => When one task waits, run another task.
# single thread 

import asyncio

async def work():
    print("Start")
    await asyncio.sleep(1)
    print("End")

asyncio.run(work())

# thread -> os schedules , context switch is expensive.
# asyncio -> programmer , context switch cheap . 


