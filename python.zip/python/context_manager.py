# object that implements => 
# __enter__()
# __exit__()

with open("file.txt") as f:
    data = f.read()


manager = open("file.txt")

f = manager.__enter__()

try:
    data = f.read()
finally:
    manager.__exit__()

# using a generator 

from contextlib import contextmanager

@contextmanager
def my_context():
    print("Enter")

    yield

    print("Exit")