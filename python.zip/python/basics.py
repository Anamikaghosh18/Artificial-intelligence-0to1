# basics of python

# By default input return string value 

# taking input and outputs 
name = input("what is your name: "); 
sub1 = int(input("Enter your sub1 marks: ")); 
sub2 = int(input("Enter your sub2 marks: "));

print(f"name is: ", name);
print(f"marks in sub1: ",sub1); 
print(f"Marks in sub2: ", sub2);  
