# modularity 
# same task multiple time 

# without parameter
def say_hello():
    print("Hey hello from my side"); 

say_hello(); 

# with parameter
def print_name(name):
    print(f"Hey my name is: ", name); 

print_name(input("name: ")); 

# keyword argument -> kwarg = value 
def total_cost(price, fruit = 'banana', amount=10):
    return price * amount; 

print(f"total cost is: ", total_cost(40)); # postional 
print(f"total cost is: ", total_cost(40, amount=50)); # positional and keyword argument

# anonymous functions -> lambda functions

# lambda arguments : expressions
add = lambda a, b : a + b ;

a = int(input("enter num1: ")); 
b = int(input("enter num2: ")); 
print("Sum of the numbers: ",add(a, b)); 
