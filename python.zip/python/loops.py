# for loop -> it iterate over a items of a seq (list)

subjects = ["maths", "science", "c++"]; 

for i in subjects:
    print(i, len(i));

# start , end , gap
for i in range(1, 100, 10):
    if(i % 3 == 0):
        break; # break the loop 
    print(i); 


for i in range(1, 100, 10):
    if(i % 3 == 0):
        continue; # continues to next iteration 
    print(i); 

while True:
    pass # no action or placeholder for func....



