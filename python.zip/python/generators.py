# all values returns 

def get_nums():
    return [1,23,30]

print(get_nums()) # return and destroy teh stack frame 


# generators -> lazy evaluation

def nums():
    yield 1 


# yield -> returns a value, pauses the exe + saves its state + continue from there 

# local var 
# instaruction pointer
# exe stack

g = nums() # not generate anything 

# send(value) -> sends back to generator
# throw()
# next()
# iter()
# once used exhaused 