# arr = [1,6,29,10];

# def get_sum(arr):
#     total_sum = 0 
#     for i in arr:
#         total_sum += i 

#     return total_sum ; 

# sum = get_sum(arr)
# print("sum of all elements: " , sum); 


#-------------------------------------------------------------------------------

# arr = [1,2,45,8,9,0,12]
# target = 8

# def find_ele_ind(*args):
#     low = 0 ; 
#     high = len(arr)

#     while(low < high):
#         mid = low + (high - low) // 2 

#         if(arr[mid] == target):
#             return mid ; 
#         elif(arr[mid] < target):
#             low = mid + 1 
#         else:
#             high = mid - 1 
#     return -1 


# ind = find_ele_ind(arr, target)
# print("element found at index: ",ind)


#-------------------------------------------------------------------------------

## largest element 

# arr = [1, 4, 0, 89, 80]

# def find_largest(*args):
#     largest = -1 
#     for i in range(len(arr)):
#         if(arr[i] > largest):
#             largest = arr[i]

#     return largest 


# largest_ele = find_largest(arr)
# print(f"largest ele is: {largest_ele}")

#-------------------------------------------------------------------------------

# second largest 

# arr = [1,10, 9, 11, 12]

# def second_largest(*args):
#     largest = float('-inf')
#     slargest = float('-inf')

#     for num in arr:
#         if num > largest :
#             slargest = largest
#             largest = num
             
#         elif num > slargest and num != largest:
#             slargest = num

        
#     return slargest 

# second_largest_ele = second_largest(arr)
# print(f"second largest: {second_largest_ele}")

#=------------------------------------------------------------------------------

# arr = [1,2,4,4,1,3]

# # first non-repeating number 
# def non_repeating(*args):
#     freq_dict = {}
#     for num in arr:
#         freq_dict[num] = freq_dict.get(num, 0) + 1

#     for num in arr:
#         if(freq_dict[num] == 1):
#             return num 

# non_repeating_num = non_repeating(arr)
# print(f"non repeating : {non_repeating_num}")

#-------------------------------------------------------------------------------

# arr = [6, 4, 1, 9, 0, 2]
# target = 8 

# def two_sum(*args):
#     sum_dict = {}
#     for i in range(len(arr)):
#         sum_need = target - arr[i]
    
#         if sum_need in sum_dict:
#             return (sum_dict[sum_need], i)
        
#         sum_dict[arr[i]] = i

        
# index = two_sum(arr, target)
# print(f"indexes are: {index}")

#-------------------------------------------------------------------------------

# return all the duplicates
nums = [1,2,2, 3,4,4]

def find_duplicates(nums):
    non_dup_set = set()
    result = []
    for num in nums:
        if num in non_dup_set:
            result.append(num)
        
        non_dup_set.add(num)

    return result

print(f"non duplicate ele: {find_duplicates(nums)}")


