# Control flow statements 

# if -else 

marks = int(input("Enter your marks: ")); 

if(marks > 90):
    print("1st division"); 
elif(marks >= 65 and marks < 90):
    print("2nd division");
elif(marks >= 35 and marks < 65):
    print("3rd division");
else:
    print("fail"); 


# match statements -> when there are many conditions and needs to switch accordingly...

def error(status):
    match(status):
        case 400:
            print("Bad request"); 
        case 404:
            print("Page not found"); 
        case 403:
            print("Forbidden"); 


error(int(input("enter the code: "))); 


