# A descriptor is any object that implements one or more of:

# __get__() - non-data descriptor , data descriptor
# __set__() - data descriptor 
# __delete__() - data descriptor 



# lookup order 
# data descriptors 
# Data Descriptor -> Instance __dict__ -> Class __dict__ -> Parent Classes


# Instance __dict__ -> Non-data descriptor -> Class __dict__ -> Parent Classes

# functions are descriptors...

class A:

    def hello(self):
        print("Hi")


# function object
# bound method


@property
@classmethod



